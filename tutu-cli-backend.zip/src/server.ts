import * as Koa from 'koa';
import * as logger from 'koa-logger';
const app = new Koa();
const mid1 = async (ctx:any, next:any) => {
  ctx.type = 'text/html; charset=utf-8';
  ctx.body = 'firest ';

  await next();
}

const mid2 = async (ctx:any, next:any) => {
  ctx.body += 'hahaha';
  await next();
}
// app.use(router.routes());
app.use(logger());
app.use(mid1);
app.use(mid2);

app.listen(8080);
console.log("Server running on port 8008");

